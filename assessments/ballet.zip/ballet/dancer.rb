class Dancer
  attr_reader :name
  attr_accessor :age, :card

  def initialize(name, age)
    @name = name
    @age = age
    @card = []
  end

  def begin_next_dance
    partner = @card[0]
     @card.slice!(0)
    return "Now dancing with #{partner}."

  end

  def bow
    return "*bows*"
  end

  def pirouette
    return "*twirls*"
  end

  def queue_dance_with(name_of_partner)
    @card << name_of_partner
    @card.slice!(3)
  end

  def remove_dancer
    @card.delete_at(0)
    return @card
  end
end